# Tarea_Clonando_C-digo
Repositorio para la tarea 5.2 de TIC2 en el IEDA
Esta página web permite alternar entre varios estilos predefinidos.
